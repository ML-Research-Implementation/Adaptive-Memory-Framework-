import os
import argparse
import time
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoTokenizer

from config import MODEL_NAME, DEVICE
from src.squad_data import get_squad_dataloaders
from src.models_adaptive import AdaptiveDistilBertQA
from src.baseline import BaselineQAModel
from src.utils import set_seed, print_header, save_checkpoint, load_checkpoint
from evaluate_squad import evaluate_model
from train_phase5 import train_phase5

# We will modify train_phase5 logic slightly here to support ablations
from torch.optim import AdamW
from transformers import get_linear_schedule_with_warmup
from src.losses import calculate_distillation_loss, calculate_lagrangian_budget_loss, calculate_hidden_state_distillation_loss

def train_ablation(name, lambda_kd, lambda_h, max_train_samples=5000, epochs=5):
    set_seed(42)
    print_header(f"TRAINING ABLATION: {name}")
    
    batch_size = 2
    train_dl, _, _, _, _ = get_squad_dataloaders(batch_size=batch_size, max_train_samples=max_train_samples, max_val_samples=10)
    
    teacher = BaselineQAModel(freeze_parameters=True)
    teacher.qa_model.eval()
    
    student = AdaptiveDistilBertQA(model_name=MODEL_NAME, device=DEVICE, freeze_transformer=True)
    student.unfreeze_scorers()
    student.train()
    
    optimizer = AdamW(student.retention_scorers.parameters(), lr=3e-3)
    total_steps = len(train_dl) * epochs
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=int(0.1*total_steps), num_training_steps=total_steps)
    
    lagrangian_multiplier = 0.0
    lagrangian_lr = 0.05
    curriculum = [0.95, 0.90, 0.80, 0.70, 0.60]
    
    for epoch in range(epochs):
        target_ratio = curriculum[min(epoch, len(curriculum)-1)]
        progress_bar = tqdm(train_dl, desc=f"Epoch {epoch+1} [{name}]")
        
        for batch in progress_bar:
            input_ids = batch['input_ids'].to(DEVICE)
            attention_mask = batch['attention_mask'].to(DEVICE)
            start_target = batch['start_positions'].to(DEVICE)
            end_target = batch['end_positions'].to(DEVICE)
            
            target_budget_per_seq = 6 * input_ids.size(1) * target_ratio
            
            with torch.no_grad():
                teacher_outputs = teacher.model(input_ids, attention_mask, output_hidden_states=True)
                t_start = teacher_outputs.start_logits
                t_end = teacher_outputs.end_logits
                t_hidden = teacher_outputs.hidden_states
                
            s_start, s_end, layer_metrics = student(input_ids, attention_mask, return_layer_metrics=True, training=True)
            expected_retained = layer_metrics['expected_retained_tokens']
            
            qa_loss = (F.cross_entropy(s_start, start_target) + F.cross_entropy(s_end, end_target)) / 2
            
            logit_kd_loss = torch.tensor(0.0, device=DEVICE)
            if lambda_kd > 0:
                logit_kd_loss = calculate_distillation_loss(s_start, s_end, t_start, t_end)
                
            hidden_kd_loss = torch.tensor(0.0, device=DEVICE)
            if lambda_h > 0:
                for l_idx in range(6):
                    if layer_metrics['selection_results'][l_idx] is not None:
                        h_loss = calculate_hidden_state_distillation_loss(
                            layer_metrics['hidden_states'][l_idx], t_hidden[l_idx+1],
                            layer_metrics['selection_results'][l_idx].selected_indices,
                            layer_metrics['selection_results'][l_idx].new_attention_mask
                        )
                        hidden_kd_loss += h_loss
                        
            budget_loss = calculate_lagrangian_budget_loss(expected_retained, target_budget_per_seq, lagrangian_multiplier)
            total_loss = qa_loss + lambda_kd * logit_kd_loss + lambda_h * hidden_kd_loss + 1.0 * budget_loss
            
            optimizer.zero_grad()
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(student.retention_scorers.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            
            with torch.no_grad():
                lagrangian_multiplier = max(0.0, lagrangian_multiplier + lagrangian_lr * (expected_retained - target_budget_per_seq).item())
                
    save_checkpoint(student, optimizer=optimizer, step=0, checkpoint_path=f"ablation_{name}.pt")
    del teacher, student, optimizer, scheduler
    torch.cuda.empty_cache() if torch.cuda.is_available() else None


def calibrate_threshold(model, calibration_dl, target_ratio: float, tolerance: float = 0.01) -> float:
    """
    Binary search on a calibration set to find the threshold_bias that achieves the target average retention.
    """
    low, high = -10.0, 10.0
    best_bias = 0.0
    
    print(f"Calibrating threshold for target retention {target_ratio*100:.1f}%...")
    model.eval()
    
    for _ in range(15): # Max 15 iterations of binary search
        mid = (low + high) / 2
        total_retained, total_original = 0, 0
        
        for batch in calibration_dl:
            with torch.no_grad():
                _, _, metrics = model(
                    batch['input_ids'].to(DEVICE), 
                    batch['attention_mask'].to(DEVICE), 
                    return_layer_metrics=True, 
                    training=False, 
                    threshold_bias=mid
                )
                for res in metrics['selection_results']:
                    if res is not None:
                        total_retained += res.num_selected
                        total_original += res.num_original
        
        current_ratio = total_retained / max(1, total_original)
        
        if abs(current_ratio - target_ratio) <= tolerance:
            best_bias = mid
            break
        elif current_ratio > target_ratio: # Kept too many tokens -> lower the bias
            high = mid
        else: # Kept too few tokens -> raise the bias
            low = mid
            
        best_bias = mid
        
    print(f"  Found bias = {best_bias:.3f} (Achieved {current_ratio*100:.1f}%)")
    return best_bias


def main(test_mode=False):
    max_train = 50 if test_mode else 5000
    epochs = 1 if test_mode else 5
    max_val = 20 if test_mode else 1000  # Evaluate on same large subset!
    
    # Train ablations
    train_ablation("QA_Only", lambda_kd=0.0, lambda_h=0.0, max_train_samples=max_train, epochs=epochs)
    train_ablation("Logit_KD", lambda_kd=1.0, lambda_h=0.0, max_train_samples=max_train, epochs=epochs)
    train_ablation("Full_KD", lambda_kd=1.0, lambda_h=1.0, max_train_samples=max_train, epochs=epochs)
    
    # Evaluation
    print_header("PHASE 5 ABLATION EVALUATION")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    _, val_dl, _, val_data, val_features = get_squad_dataloaders(batch_size=4, max_train_samples=10, max_val_samples=max_val)
    
    # Calibration set (use a small subset of val)
    _, cal_dl, _, _, _ = get_squad_dataloaders(batch_size=4, max_train_samples=10, max_val_samples=50)
    
    results = []
    
    # 1. Baseline
    baseline = BaselineQAModel(freeze_parameters=True)
    b_em, b_f1, b_lat, _, _ = evaluate_model(baseline, val_dl, val_features, val_data, tokenizer, is_baseline=True)
    results.append(["Baseline", "100%", b_em, b_f1, 100.0, 100.0, b_lat, 0.0])
    del baseline
    
    # 2. AMMR Models
    models_to_eval = ["QA_Only", "Logit_KD", "Full_KD"]
    budgets = [0.90, 0.80, 0.70, 0.60, 0.50]
    
    for name in models_to_eval:
        ammr = AdaptiveDistilBertQA(model_name=MODEL_NAME, device=DEVICE)
        load_checkpoint(ammr, optimizer=None, checkpoint_path=f"ablation_{name}.pt")
        
        for b in budgets:
            print(f"\nEvaluating {name} at {b*100:.0f}% Budget")
            bias = calibrate_threshold(ammr, cal_dl, target_ratio=b)
            em, f1, lat, ret, cost = evaluate_model(ammr, val_dl, val_features, val_data, tokenizer, is_baseline=False, threshold_bias=bias)
            drop = b_f1 - f1
            results.append([name, f"{b*100:.0f}%", em, f1, ret, cost, lat, drop])
            
        del ammr
        torch.cuda.empty_cache() if torch.cuda.is_available() else None
        
    # Print Table
    print_header("FINAL PARETO CURVE: ACCURACY-EFFICIENCY ABLATION")
    print(f"{'Model':<15} | {'Budget':<8} | {'EM':<8} | {'F1':<8} | {'Retained %':<12} | {'Attn Cost':<12} | {'Latency (ms)':<15} | {'F1 Drop':<8}")
    print("-" * 95)
    for res in results:
        m, b, em, f1, ret, cost, lat, drop = res
        print(f"{m:<15} | {b:<8} | {em:<8.2f} | {f1:<8.2f} | {ret:<12.1f} | {cost:<12.1f} | {lat:<15.2f} | {drop:<8.2f}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--test", action="store_true", help="Run in fast test mode (small data)")
    args = parser.parse_args()
    main(args.test)
